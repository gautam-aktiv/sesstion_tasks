# -*- coding: utf-8 -*-
from . import res_config
from . import hr_employees